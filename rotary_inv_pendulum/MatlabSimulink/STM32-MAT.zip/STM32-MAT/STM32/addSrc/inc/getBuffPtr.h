#ifndef GET_BUFF_PTR_H
#define GET_BUFF_PTR_H

#include <stdint.h>

/* Function prototype used from MATLAB script. */
extern uint32_t getBuffPtr(const void *);

#endif
