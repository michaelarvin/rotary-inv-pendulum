#ifndef __getSpiDataValue_H
#define __getSpiDataValue_H
#include <stdint.h>

extern unsigned int getSpiDataValue(uint32_t);
extern char SPIMsgBuff[20];

#endif

